<?php
/**
 * Image Header Block Template
 *
 *
 * @package Ming Johanson
 * @version 1.0
 */
?>

<div class="banner sub">
   <?php 
      echo '<img src="' . get_field('image') . '" />';
   ?>
</div>
