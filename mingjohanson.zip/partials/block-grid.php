<?php
/**
 * Grid Container Block Template
 *
 *
 * @package Ming Johanson
 * @version 1.0
 */
?>
    <section class="grid">
    </section>